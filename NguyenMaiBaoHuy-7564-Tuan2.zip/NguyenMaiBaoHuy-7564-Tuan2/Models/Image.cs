﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NguyenMaiBaoHuy_7564_Tuan2.Models
{
    public class Image
    {
        public int id { get; set; }
        public int path { get; set; }
    }
}